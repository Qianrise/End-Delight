package cn.Qianrise.end_delight;

import cn.Qianrise.end_delight.item.ItemRegistry;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class EndDelightGroup extends ItemGroup {
    public static final EndDelightGroup end_delightGroup = new EndDelightGroup();

    public EndDelightGroup() {
        super("End Delight Group");
    }

    @Override
    public ItemStack makeIcon() {
        return new ItemStack(ItemRegistry.ChorusFruitMilkTea.get());
    }
}
