package cn.Qianrise.end_delight;

import cn.Qianrise.end_delight.item.ItemRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("end_delight")
public class EndDelight {
    public EndDelight() {
        ItemRegistry.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }
}