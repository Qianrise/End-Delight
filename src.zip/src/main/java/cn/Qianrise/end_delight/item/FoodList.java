package cn.Qianrise.end_delight.item;

import net.minecraft.item.Food;

public class FoodList {
    public static final Food ChorusFruitGrain = new Food.Builder().nutrition(1).saturationMod(0.6F).alwaysEat().build();
    public static final Food ChorusFruitMilkTea = new Food.Builder().nutrition(6).saturationMod(0.5F).alwaysEat().build();
    public static final Food BubbleTea = new Food.Builder().nutrition(8).saturationMod(0.5F).alwaysEat().build();
    public static final Food ShulkerMeat = new Food.Builder().nutrition(4).saturationMod(0.5F).alwaysEat().build();
    public static final Food ShulkerMeatSlice = new Food.Builder().nutrition(2).saturationMod(0.6F).alwaysEat().build();
    public static final Food StirFriedShulkerMeat = new Food.Builder().nutrition(10).saturationMod(0.8F).alwaysEat().build();
}
