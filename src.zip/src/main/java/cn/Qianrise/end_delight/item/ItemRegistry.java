package cn.Qianrise.end_delight.item;

import cn.Qianrise.end_delight.EndDelightGroup;
import cn.Qianrise.end_delight.Utils;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ItemRegistry {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Utils.MOD_ID);

    public static final RegistryObject<Item> EnderPearlGrain = ITEMS.register("ender_pearl_grain", ()-> new Item(new Item.Properties().tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> ChorusFruitGrain = ITEMS.register("chorus_fruit_grain", ()-> new Item(new Item.Properties().food(FoodList.ChorusFruitGrain).tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> ChorusFruitMilkTea = ITEMS.register("chorus_fruit_milk_tea", ()-> new Item(new Item.Properties().food(FoodList.ChorusFruitMilkTea).tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> BubbleTea = ITEMS.register("bubble_tea", ()-> new Item(new Item.Properties().food(FoodList.BubbleTea).tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> ShulkerMeat = ITEMS.register("shulker_meat", ()-> new Item(new Item.Properties().food(FoodList.ShulkerMeat).tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> ShulkerMeatSlice = ITEMS.register("shulker_meat_slice", ()-> new Item(new Item.Properties().food(FoodList.ShulkerMeatSlice).tab(EndDelightGroup.end_delightGroup)));
    public static final RegistryObject<Item> StirFriedShulkerMeat = ITEMS.register("stir_fried_shulker_meat", ()-> new Item(new Item.Properties().food(FoodList.StirFriedShulkerMeat).tab(EndDelightGroup.end_delightGroup)));
}
