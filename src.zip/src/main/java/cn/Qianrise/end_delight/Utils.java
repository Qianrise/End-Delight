package cn.Qianrise.end_delight;

public class Utils {
    public static final String MOD_ID = "end_delight";
}
